# INQ EDU Website V1
GitHub Pages ready.
Upload your logo to assets/logo.png